package com.example.hw2lazycolumnnavigation

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.hw2lazycolumnnavigation.ui.theme.HW2LazyColumnNavigationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HW2LazyColumnNavigationTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    MyApp()
                }
            }
        }
    }
}

@Composable
fun MyApp() {
    val places = listOf(
        "台北101", "桃園華泰名品城", "新竹", "苗栗客家圓樓", "台中審計新村", "彰化八卦山", "南投日月潭", "嘉義阿里山"
    )
    val images = listOf(
        R.drawable.image1, R.drawable.image2, R.drawable.image3, R.drawable.image4,
        R.drawable.image5, R.drawable.image6, R.drawable.image7, R.drawable.image8
    )
    var currentIndexState by remember { mutableStateOf(-1) }

    if (currentIndexState == -1) {
        PlaceList(places) { index -> currentIndexState = index }
    } else {
        PlaceDetailScreen(
            placeName = places[currentIndexState],
            imageRes = images[currentIndexState],
            onBack = { currentIndexState = -1 }
        )
    }
}

@Composable
fun PlaceList(places: List<String>, onItemClick: (Int) -> Unit) {
    LazyColumn {
        items(places) { placeName ->
            val index = places.indexOf(placeName)
            if(index!=-1) {
                PlaceItem(placeName, index, onItemClick)
            }
        }
    }
}

@Composable
fun PlaceItem(placeName: String, index: Int, onItemClick: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onItemClick(index) }
            .padding(80.dp)
    ) {
        Text(text = placeName)
    }
}

@Composable
fun PlaceDetailScreen(placeName: String, imageRes: Int, onBack: () -> Unit) {
    val context = LocalContext.current

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
            ) {
                Image(
                    painter = painterResource(id = imageRes),
                    contentDescription = placeName,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Text(
                text = placeName,
                modifier = Modifier.padding(16.dp)
            )
            Text(
                text = "詳細位置",
                modifier = Modifier
                    .padding(16.dp)
                    .clickable {
                        val gmmIntentUri = Uri.parse("geo:0,0?q=$placeName")
                        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                        mapIntent.setPackage("com.google.android.apps.maps")
                        context.startActivity(mapIntent)
                    }
            )
            Spacer(modifier = Modifier.height(8.dp))
        }
        Text(
            text = "<---前一頁",
            modifier = Modifier
                .padding(16.dp)
                .align(Alignment.TopStart)
                .clickable { onBack() }
        )
    }
}
